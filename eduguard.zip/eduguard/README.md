# EduGuard Project

Upload this to GitHub.